﻿using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Controls
{
	internal static class VisualStates
	{
		public const string GroupCommon = "CommonStates";
		public const string StateNormal = "Normal";
		public const string StateReadOnly = "ReadOnly";
		public const string StateMouseOver = "MouseOver";
		public const string StatePressed = "Pressed";
		public const string StateDisabled = "Disabled";
		public const string GroupFocus = "FocusStates";
		public const string StateUnfocused = "Unfocused";
		public const string StateFocused = "Focused";
		public const string GroupSelection = "SelectionStates";
		public const string StateSelected = "Selected";
		public const string StateUnselected = "Unselected";
		public const string StateSelectedInactive = "SelectedInactive";
		public const string GroupExpansion = "ExpansionStates";
		public const string StateExpanded = "Expanded";
		public const string StateCollapsed = "Collapsed";
		public const string GroupPopup = "PopupStates";
		public const string StatePopupOpened = "PopupOpened";
		public const string StatePopupClosed = "PopupClosed";
		public const string GroupValidation = "ValidationStates";
		public const string StateValid = "Valid";
		public const string StateInvalidFocused = "InvalidFocused";
		public const string StateInvalidUnfocused = "InvalidUnfocused";
		public const string GroupExpandDirection = "ExpandDirectionStates";
		public const string StateExpandDown = "ExpandDown";
		public const string StateExpandUp = "ExpandUp";
		public const string StateExpandLeft = "ExpandLeft";
		public const string StateExpandRight = "ExpandRight";
		public const string GroupHasItems = "HasItemsStates";
		public const string StateHasItems = "HasItems";
		public const string StateNoItems = "NoItems";
		public const string GroupIncrease = "IncreaseStates";
		public const string StateIncreaseEnabled = "IncreaseEnabled";
		public const string StateIncreaseDisabled = "IncreaseDisabled";
		public const string GroupDecrease = "DecreaseStates";
		public const string StateDecreaseEnabled = "DecreaseEnabled";
		public const string StateDecreaseDisabled = "DecreaseDisabled";
		public const string GroupInteractionMode = "InteractionModeStates";
		public const string StateEdit = "Edit";
		public const string StateDisplay = "Display";
		public const string GroupLocked = "LockedStates";
		public const string StateLocked = "Locked";
		public const string StateUnlocked = "Unlocked";
		public const string StateActive = "Active";
		public const string StateInactive = "Inactive";
		public const string GroupActive = "ActiveStates";
		public const string StateUnwatermarked = "Unwatermarked";
		public const string StateWatermarked = "Watermarked";
		public const string GroupWatermark = "WatermarkStates";
		public const string StateCalendarButtonUnfocused = "CalendarButtonUnfocused";
		public const string StateCalendarButtonFocused = "CalendarButtonFocused";
		public const string GroupCalendarButtonFocus = "CalendarButtonFocusStates";
		public const string StateBusy = "Busy";
		public const string StateIdle = "Idle";
		public const string GroupBusyStatus = "BusyStatusStates";
		public const string StateVisible = "Visible";
		public const string StateHidden = "Hidden";
		public const string GroupVisibility = "VisibilityStates";

		/// <summary>
		/// Use VisualStateManager to change the visual state of the control.
		/// </summary>
		/// <param name="control">
		/// Control whose visual state is being changed.
		/// </param>
		/// <param name="useTransitions">
		/// A value indicating whether to use transitions when updating the
		/// visual state, or to snap directly to the new visual state.
		/// </param>
		/// <param name="stateNames">
		/// Ordered list of state names and fallback states to transition into.
		/// Only the first state to be found will be used.
		/// </param>
		public static void GoToState(Control control, bool useTransitions, params string[] stateNames)
		{
			Debug.Assert(control != null, "control should not be null!");
			Debug.Assert(stateNames != null, "stateNames should not be null!");
			Debug.Assert(stateNames.Length > 0, "stateNames should not be empty!");

			foreach (string name in stateNames.Where(name => VisualStateManager.GoToState(control, name, useTransitions)))
			{
				break;
			}
		}

		/// <summary>
		/// Gets the implementation root of the Control.
		/// </summary>
		/// <param name="dependencyObject">The DependencyObject.</param>
		/// <remarks>
		/// Implements Silverlight corresponding internal property on Control.
		/// </remarks>
		/// <returns>Returns the implementation root or null.</returns>
		public static FrameworkElement GetImplementationRoot(DependencyObject dependencyObject)
		{
			Debug.Assert(dependencyObject != null, "DependencyObject should not be null.");
			return (1 == VisualTreeHelper.GetChildrenCount(dependencyObject)) ? 
				   VisualTreeHelper.GetChild(dependencyObject, 0) as FrameworkElement : null;
		}

		/// <summary>
		/// This method tries to get the named VisualStateGroup for the 
		/// dependency object. The provided object's ImplementationRoot will be 
		/// looked up in this call.
		/// </summary>
		/// <param name="dependencyObject">The dependency object.</param>
		/// <param name="groupName">The visual state group's name.</param>
		/// <returns>Returns null or the VisualStateGroup object.</returns>
		public static VisualStateGroup TryGetVisualStateGroup(DependencyObject dependencyObject, string groupName)
		{
			FrameworkElement root = GetImplementationRoot(dependencyObject);
			// ReSharper disable AssignNullToNotNullAttribute
			return root == null ? null : VisualStateManager.GetVisualStateGroups(root).OfType<VisualStateGroup>().FirstOrDefault(group => string.CompareOrdinal(groupName, @group.Name) == 0);
			// ReSharper restore AssignNullToNotNullAttribute
		}
	}
}
