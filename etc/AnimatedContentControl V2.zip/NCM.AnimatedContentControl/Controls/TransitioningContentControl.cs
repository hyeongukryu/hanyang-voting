﻿using System;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;


namespace Controls
{
	[TemplateVisualState(GroupName = "PresentationStates", Name = "DefaultTransition")]
	[TemplatePart(Name = "CurrentContentPresentationSite", Type = typeof (ContentControl))]
	[TemplateVisualState(GroupName = "PresentationStates", Name = "Normal")]
	[TemplatePart(Name = "PreviousContentPresentationSite", Type = typeof (ContentControl))]
	public class TransitioningContentControl : ContentControl
	{
		private const string PresentationGroup = "PresentationStates";
		private const string NormalState = "Normal";
		public const string DefaultTransitionState = "DefaultTransition";
		internal const string PreviousContentPresentationSitePartName = "PreviousContentPresentationSite";
		internal const string CurrentContentPresentationSitePartName = "CurrentContentPresentationSite";


		public event RoutedEventHandler TransitionCompleted;

		public static readonly DependencyProperty IsTransitioningProperty =
			DependencyProperty.Register("IsTransitioning", typeof (bool), typeof (TransitioningContentControl),
			                            new PropertyMetadata(OnIsTransitioningPropertyChanged));

		public static readonly DependencyProperty TransitionProperty =
			DependencyProperty.Register("Transition", typeof (string), typeof (TransitioningContentControl),
			                            new PropertyMetadata("DefaultTransition", OnTransitionPropertyChanged));

		public static readonly DependencyProperty RestartTransitionOnContentChangeProperty =
			DependencyProperty.Register("RestartTransitionOnContentChange", typeof (bool),
			                            typeof (TransitioningContentControl),
			                            new PropertyMetadata(false, OnRestartTransitionOnContentChangePropertyChanged));


		private bool _allowIsTransitioningWrite;
		private Storyboard _currentTransition;

		static TransitioningContentControl()
		{
		}

		public TransitioningContentControl()
		{
			DefaultStyleKey = typeof (TransitioningContentControl);
		}

		//private RoutedEventHandler TransitionCompleted;

		private ContentPresenter CurrentContentPresentationSite { get; set; }

		private ContentPresenter PreviousContentPresentationSite { get; set; }

		public bool IsTransitioning
		{
			get { return (bool) GetValue(IsTransitioningProperty); }
			private set
			{
				_allowIsTransitioningWrite = true;
				SetValue(IsTransitioningProperty, value);
				_allowIsTransitioningWrite = false;
			}
		}

		private Storyboard CurrentTransition
		{
			get { return _currentTransition; }
			set
			{
				if (_currentTransition != null)
				{
					_currentTransition.Completed -= OnTransitionCompleted;
				}
				_currentTransition = value;
				if (_currentTransition == null)
				{return;}
				_currentTransition.Completed += OnTransitionCompleted;
			}
		}

		public string Transition
		{
			get { return GetValue(TransitionProperty) as string; }
			set { SetValue(TransitionProperty, value); }
		}

		public bool RestartTransitionOnContentChange
		{
			get { return (bool) GetValue(RestartTransitionOnContentChangeProperty); }
			set { SetValue(RestartTransitionOnContentChangeProperty, value); }
		}

		private static void OnIsTransitioningPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			var transitioningContentControl = (TransitioningContentControl) d;
			if (transitioningContentControl._allowIsTransitioningWrite)
				return;
			transitioningContentControl.IsTransitioning = (bool) e.OldValue;
			throw new InvalidOperationException("");
		}

		private static void OnTransitionPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			var transitioningContentControl = (TransitioningContentControl) d;
			var str = e.NewValue as string;
			var newTransition = e.NewValue as string;
			if (transitioningContentControl.IsTransitioning)
				transitioningContentControl.AbortTransition();
			Storyboard storyboard = transitioningContentControl.GetStoryboard(newTransition);
			if (storyboard == null)
			{
				if (VisualStates.TryGetVisualStateGroup(transitioningContentControl, "PresentationStates") ==
				    null)
				{
					transitioningContentControl.CurrentTransition = null;
				}
				else
				{
					transitioningContentControl.SetValue(TransitionProperty, str);
					throw new ArgumentException(string.Format(CultureInfo.CurrentCulture, "{0}", new object[] {newTransition}));
				}
			}
			else
				transitioningContentControl.CurrentTransition = storyboard;
		}

		private static void OnRestartTransitionOnContentChangePropertyChanged(DependencyObject d,
		                                                                      DependencyPropertyChangedEventArgs e)
		{
			((TransitioningContentControl) d).OnRestartTransitionOnContentChangeChanged((bool) e.OldValue, (bool) e.NewValue);
		}

		protected virtual void OnRestartTransitionOnContentChangeChanged(bool oldValue, bool newValue)
		{
		}

		public override void OnApplyTemplate()
		{
			if (IsTransitioning)
				AbortTransition();
			base.OnApplyTemplate();
			PreviousContentPresentationSite = GetTemplateChild("PreviousContentPresentationSite") as ContentPresenter;
			CurrentContentPresentationSite = GetTemplateChild("CurrentContentPresentationSite") as ContentPresenter;
			if (CurrentContentPresentationSite != null)
				CurrentContentPresentationSite.Content = Content;
			Storyboard storyboard = GetStoryboard(Transition);
			CurrentTransition = storyboard;

			if (storyboard == null)
			{
				string transition = Transition;
				Transition = "DefaultTransition";
				throw new ArgumentException(string.Format(CultureInfo.CurrentCulture, "{0}", new object[]{transition}));
			}

			VisualStateManager.GoToState(this, "Normal", false);
		}

		protected override void OnContentChanged(object oldContent, object newContent)
		{
			base.OnContentChanged(oldContent, newContent);
			StartTransition(oldContent, newContent);
		}

		private void StartTransition(object oldContent, object newContent)
		{
			if (CurrentContentPresentationSite == null || PreviousContentPresentationSite == null)
				return;
			CurrentContentPresentationSite.Content = newContent;
			PreviousContentPresentationSite.Content = oldContent;
			if (IsTransitioning && !RestartTransitionOnContentChange)
				return;
			IsTransitioning = true;
			VisualStateManager.GoToState(this, "Normal", false);
			VisualStateManager.GoToState(this, Transition, true);
		}

		private void OnTransitionCompleted(object sender, EventArgs e)
		{
			AbortTransition();
			RoutedEventHandler routedEventHandler = TransitionCompleted;
			if (routedEventHandler == null)
				return;
			routedEventHandler(this, new RoutedEventArgs());
		}

		public void AbortTransition()
		{
			VisualStateManager.GoToState(this, "Normal", false);
			IsTransitioning = false;
			if (PreviousContentPresentationSite == null)
				return;
			PreviousContentPresentationSite.Content = null;
		}

		private Storyboard GetStoryboard(string newTransition)
		{
			VisualStateGroup visualStateGroup = VisualStates.TryGetVisualStateGroup(this, "PresentationStates");
			Storyboard storyboard = null;
			if (visualStateGroup != null)
				storyboard =
					(visualStateGroup.States).OfType<VisualState>().Where((state => state.Name == newTransition)).Select(
						(state => state.Storyboard)).FirstOrDefault();
			return storyboard;
		}
	}
}