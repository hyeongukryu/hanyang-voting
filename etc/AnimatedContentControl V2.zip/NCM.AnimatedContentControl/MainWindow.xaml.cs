﻿using System.Windows;

namespace Controls
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{

            if (tcc.Content.Equals("SOME NEW CONTENT"))
            {
                tcc.Content = "THIS IS A TEST";
            }
            else
            {
                tcc.Content = "SOME NEW CONTENT";
            }

		}
	}
}
